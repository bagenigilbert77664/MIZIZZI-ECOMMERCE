"""
Admin inventory tests package for Mizizzi E-commerce platform.
"""
