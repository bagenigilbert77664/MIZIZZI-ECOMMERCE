"""
Admin Review Tests Package

This package contains comprehensive tests for admin review management functionality
in the Mizizzi E-commerce platform.
"""
