"""
Admin products tests package.
Contains comprehensive tests for admin product management functionality.
"""
