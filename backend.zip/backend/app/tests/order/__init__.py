"""
Order tests package for Mizizzi E-commerce platform.
"""
