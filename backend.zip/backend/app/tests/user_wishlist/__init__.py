"""
Test package for user wishlist functionality.
"""
