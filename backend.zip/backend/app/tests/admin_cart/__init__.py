"""
Admin cart tests package.
"""
