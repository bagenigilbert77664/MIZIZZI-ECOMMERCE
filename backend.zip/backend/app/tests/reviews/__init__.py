"""
Tests for review functionality in Mizizzi E-commerce platform.
"""
