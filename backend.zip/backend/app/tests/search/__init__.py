"""
Search tests package initialization.
"""
