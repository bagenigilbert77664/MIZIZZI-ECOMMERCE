"""
Test package for inventory functionality.
"""
