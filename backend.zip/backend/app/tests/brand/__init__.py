"""
Brand routes tests package.
"""
