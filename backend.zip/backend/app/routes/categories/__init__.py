"""
Categories routes package initialization.
"""
from .categories_routes import categories_routes

__all__ = ['categories_routes']
