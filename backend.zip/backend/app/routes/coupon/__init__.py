"""
Coupon routes package for Mizizzi E-commerce platform.
"""
from .coupon_routes import validation_routes

__all__ = ['validation_routes']
