import { FileText } from "lucide-react"

export { FileText }
