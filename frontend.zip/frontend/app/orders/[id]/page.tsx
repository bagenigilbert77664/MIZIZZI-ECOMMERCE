"use client"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import {
  ArrowLeft,
  Truck,
  FileText,
  Calendar,
  ShoppingBag,
  CheckCircle,
  RefreshCw,
  ShieldCheck,
  Award,
  MessageSquare,
  Phone,
  AlertTriangle,
  XCircle,
  CreditCard,
  Package,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { orderService } from "@/services/orders"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { Order } from "@/types"
import { use, Suspense } from "react"

// Extend the OrderItem type to include the missing properties
interface OrderItem {
  id: string
  product_id: string
  quantity: number
  price: number
  product?: {
    name?: string
    thumbnail_url?: string
    image_urls?: string[]
  }
  product_name?: string
  name?: string
  thumbnail_url?: string
  image_url?: string
  returnable?: boolean
  original_price?: number
}

function OrderDetailsSkeleton() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        <div className="apple-card p-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <Skeleton className="h-8 w-48" />
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
              <Skeleton className="h-4 w-40" />
            </div>
            <div className="flex gap-3">
              <Skeleton className="h-10 w-32 rounded-full" />
              <Skeleton className="h-10 w-28 rounded-full" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="apple-card p-8">
              <Skeleton className="h-6 w-40 mb-6" />
              <div className="space-y-6">
                {[...Array(2)].map((_, i) => (
                  <div key={i} className="flex gap-4 p-4 rounded-xl bg-gray-50">
                    <Skeleton className="h-20 w-20 rounded-xl" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-5 w-48" />
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="apple-card p-6">
                <Skeleton className="h-6 w-32 mb-4" />
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function OrderPageContent({ orderId }: { orderId: string }) {
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("details")
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false)
  const [cancelling, setCancelling] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const fetchOrder = async () => {
      if (!orderId) {
        console.error("[v0] OrderPage: orderId is falsy:", orderId)
        setError("Invalid order ID - orderId is missing")
        setLoading(false)
        return
      }

      if (typeof orderId !== "string") {
        console.error("[v0] OrderPage: orderId is not a string:", typeof orderId, orderId)
        setError("Invalid order ID - orderId is not a string")
        setLoading(false)
        return
      }

      if (orderId.trim() === "") {
        console.error("[v0] OrderPage: orderId is empty string")
        setError("Invalid order ID - orderId is empty")
        setLoading(false)
        return
      }

      try {
        setLoading(true)
        console.log("[v0] OrderPage: Fetching order with ID:", orderId)
        const data = await orderService.getOrderById(orderId)

        console.log("[v0] OrderPage: Raw API response:", data)
        console.log("[v0] OrderPage: Order items detailed analysis:")

        if (data?.items && Array.isArray(data.items)) {
          data.items.forEach((item: any, index: number) => {
            console.log(`[v0] Item ${index + 1}:`, {
              id: item.id,
              product_id: item.product_id,
              quantity: item.quantity,
              price: item.price,
              product_name: item.product_name,
              name: item.name,
              thumbnail_url: item.thumbnail_url,
              image_url: item.image_url,
              product: item.product,
              hasProductObject: !!item.product,
              productKeys: item.product ? Object.keys(item.product) : [],
            })
          })
        } else {
          console.log("[v0] No items found or items is not an array:", data?.items)
        }

        if (!data) {
          console.error("[v0] OrderPage: API returned null/undefined")
          setError("Order not found - API returned null")
          return
        }

        if (data.status === "error") {
          console.error("[v0] OrderPage: API returned error status:", data)
          setError("Error loading order - API returned error status")
          return
        }

        setOrder(data)
      } catch (err: any) {
        console.error("[v0] OrderPage: Failed to fetch order:", err)
        setError(err.message || "Failed to load order details")
        toast({
          title: "Error",
          description: "Could not load order details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchOrder()
  }, [orderId, toast])

  const handleCancelOrder = async () => {
    if (!order) return

    try {
      setCancelling(true)
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setOrder({
        ...order,
        status: "cancelled",
      })

      toast({
        title: "Order Cancelled",
        description: `Order #${order.order_number} has been cancelled successfully.`,
      })

      setCancelDialogOpen(false)
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to cancel order. Please try again or contact support.",
        variant: "destructive",
      })
    } finally {
      setCancelling(false)
    }
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A"
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (dateString?: string) => {
    if (!dateString) return ""
    return new Date(dateString).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getProductImage = (item: OrderItem): string => {
    console.log("[v0] Getting product image for item:", item)

    // Try product.thumbnail_url first
    if (item.product?.thumbnail_url) {
      console.log("[v0] Using product.thumbnail_url:", item.product.thumbnail_url)
      return item.product.thumbnail_url
    }

    // Try product.image_urls array
    if (item.product?.image_urls && Array.isArray(item.product.image_urls) && item.product.image_urls.length > 0) {
      console.log("[v0] Using product.image_urls[0]:", item.product.image_urls[0])
      return item.product.image_urls[0]
    }

    // Try direct thumbnail_url
    if (item.thumbnail_url) {
      console.log("[v0] Using item.thumbnail_url:", item.thumbnail_url)
      return item.thumbnail_url
    }

    // Try direct image_url
    if (item.image_url) {
      console.log("[v0] Using item.image_url:", item.image_url)
      return item.image_url
    }

    // Try constructing from product_id
    if (item.product_id) {
      const constructedUrl = `/api/products/${item.product_id}/image`
      console.log("[v0] Using constructed URL:", constructedUrl)
      return constructedUrl
    }

    console.log("[v0] Using placeholder image")
    return `/placeholder.svg?height=96&width=96&text=${encodeURIComponent(getProductName(item))}`
  }

  const getProductName = (item: OrderItem): string => {
    console.log("[v0] Getting product name for item:", item)

    if (item.product?.name) {
      console.log("[v0] Using product.name:", item.product.name)
      return item.product.name
    }

    if (item.product_name) {
      console.log("[v0] Using item.product_name:", item.product_name)
      return item.product_name
    }

    if (item.name) {
      console.log("[v0] Using item.name:", item.name)
      return item.name
    }

    // Try to get from product object if it exists
    if (item.product && typeof item.product === "object") {
      const productKeys = Object.keys(item.product)
      console.log("[v0] Available product keys:", productKeys)

      // Look for common name fields
      const nameFields = ["title", "product_name", "display_name"]
      for (const field of nameFields) {
        if (item.product[field as keyof typeof item.product]) {
          console.log(`[v0] Using product.${field}:`, item.product[field as keyof typeof item.product])
          return String(item.product[field as keyof typeof item.product])
        }
      }
    }

    if (item.product_id) {
      console.log("[v0] Using fallback with product_id:", item.product_id)
      return `Product #${item.product_id}`
    }

    console.log("[v0] Using generic fallback name")
    return "Product"
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(amount)
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "delivered":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-amber-100 text-amber-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const canCancelOrder = () => {
    if (!order) return false
    const cancellableStatuses = ["pending", "processing"]
    return cancellableStatuses.includes(order.status?.toLowerCase() || "")
  }

  if (loading) {
    return <OrderDetailsSkeleton />
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="apple-card p-12 text-center max-w-md">
          <Package className="h-16 w-16 text-gray-300 mx-auto mb-6" />
          <h3 className="apple-text-title mb-3">Order not found</h3>
          <p className="apple-text-body mb-6">
            {error || "The order you're looking for doesn't exist or you don't have permission to view it."}
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button variant="outline" onClick={() => window.location.reload()} className="apple-button-secondary">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
            <Button asChild className="apple-button-primary">
              <Link href="/orders">Back to Orders</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        {/* Header Section */}
        <div className="apple-card p-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Package className="h-8 w-8 text-gray-700" />
                <h1 className="apple-text-title">Order #{order.order_number || order.id}</h1>
                <Badge className={`${getStatusColor(order.status)} rounded-full px-3 py-1 text-xs font-medium`}>
                  {order.status?.toUpperCase() || "PENDING"}
                </Badge>
              </div>
              <div className="flex items-center gap-2 apple-text-caption">
                <Calendar className="h-4 w-4" />
                <span>
                  Placed on {formatDate(order.created_at)} at {formatTime(order.created_at)}
                </span>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" asChild className="apple-button-secondary bg-transparent">
                <Link href="/orders">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  All Orders
                </Link>
              </Button>
              <Button asChild className="apple-button-primary">
                <Link href={`/orders/${order.id}/track`}>
                  <Truck className="h-4 w-4 mr-2" />
                  Track Order
                </Link>
              </Button>
              {canCancelOrder() && (
                <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="destructive" className="rounded-full">
                      <XCircle className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="apple-card">
                    <DialogHeader>
                      <DialogTitle className="apple-text-title">
                        Cancel Order #{order.order_number || order.id}
                      </DialogTitle>
                      <DialogDescription className="apple-text-body">
                        Are you sure you want to cancel this order? This action cannot be undone.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Alert variant="destructive" className="rounded-xl">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Warning</AlertTitle>
                        <AlertDescription>
                          Cancelling this order will immediately stop processing. If payment has been made, a refund
                          will be initiated according to our refund policy.
                        </AlertDescription>
                      </Alert>
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => setCancelDialogOpen(false)}
                        className="apple-button-secondary"
                      >
                        Keep Order
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={handleCancelOrder}
                        disabled={cancelling}
                        className="rounded-full"
                      >
                        {cancelling ? (
                          <>
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></div>
                            Processing...
                          </>
                        ) : (
                          <>Cancel Order</>
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Items Section */}
            <div className="apple-card p-8">
              <div className="flex items-center gap-3 mb-8">
                <ShoppingBag className="h-6 w-6 text-gray-700" />
                <h2 className="text-xl font-semibold text-gray-900">Items in Your Order</h2>
              </div>

              {!order.items || order.items.length === 0 ? (
                <div className="text-center py-16">
                  <div className="h-20 w-20 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-6">
                    <ShoppingBag className="h-10 w-10 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">No Items Found</h3>
                  <p className="apple-text-body mb-6 max-w-md mx-auto">
                    This order appears to have no items associated with it. This might be due to:
                  </p>
                  <ul className="apple-text-body mb-6 max-w-md mx-auto text-left space-y-1">
                    <li>• Order is still being processed</li>
                    <li>• Items were removed or cancelled</li>
                    <li>• Data synchronization issue</li>
                  </ul>
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Button
                      variant="outline"
                      onClick={() => window.location.reload()}
                      className="apple-button-secondary"
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh Page
                    </Button>
                    <Button asChild className="apple-button-primary">
                      <Link href="/orders">
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Back to Orders
                      </Link>
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {(order.items as OrderItem[]).map((item, index) => {
                    const productName = getProductName(item)
                    const productImage = getProductImage(item)
                    const itemTotal = item.price * item.quantity

                    console.log(`[v0] Rendering item ${index + 1}:`, {
                      productName,
                      productImage,
                      itemTotal,
                      originalItem: item,
                    })

                    return (
                      <div
                        key={item.id || `item-${index}`}
                        className="flex gap-6 p-6 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-colors"
                      >
                        <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-xl bg-white border">
                          <Image
                            src={productImage || "/placeholder.svg"}
                            alt={productName}
                            width={96}
                            height={96}
                            className="h-full w-full object-cover object-center"
                            onError={(e) => {
                              console.log("[v0] Image failed to load:", productImage)
                              const target = e.target as HTMLImageElement
                              target.src = `/placeholder.svg?height=96&width=96&text=${encodeURIComponent(productName)}`
                            }}
                          />
                        </div>

                        <div className="flex-1 space-y-3">
                          <div>
                            <Link
                              href={`/product/${item.product_id}`}
                              className="font-semibold text-gray-900 hover:text-gray-700 text-lg leading-tight block"
                            >
                              {productName}
                            </Link>
                            <div className="apple-text-caption mt-1 space-y-1">
                              <p>Quantity: {item.quantity}</p>
                              {item.product_id && <p>Product ID: {item.product_id}</p>}
                              <p>Unit Price: {formatCurrency(item.price)}</p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <span className="text-lg font-semibold text-gray-900">{formatCurrency(itemTotal)}</span>
                              {item.original_price && item.original_price > item.price && (
                                <div className="apple-text-caption line-through">
                                  {formatCurrency(item.original_price * item.quantity)}
                                </div>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Button
                                onClick={() => router.push(`/product/${item.product_id}`)}
                                className="apple-button-secondary"
                                size="sm"
                              >
                                View Product
                              </Button>
                              <Button
                                onClick={() => router.push(`/product/${item.product_id}`)}
                                variant="outline"
                                className="apple-button-secondary"
                                size="sm"
                              >
                                Buy Again
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* Order Timeline */}
            <div className="apple-card p-8">
              <div className="flex items-center gap-3 mb-8">
                <Calendar className="h-6 w-6 text-gray-700" />
                <h2 className="text-xl font-semibold text-gray-900">Order Timeline</h2>
              </div>

              <div className="relative space-y-8">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>

                <div className="relative flex items-start gap-6">
                  <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Order Placed</h3>
                    <p className="apple-text-caption">
                      {formatDate(order.created_at)} at {formatTime(order.created_at)}
                    </p>
                  </div>
                </div>

                {order.status !== "cancelled" && (
                  <>
                    <div className="relative flex items-start gap-6">
                      <div
                        className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          order.status === "processing" || order.status === "delivered" ? "bg-blue-100" : "bg-gray-100"
                        }`}
                      >
                        {order.status === "processing" || order.status === "delivered" ? (
                          <CheckCircle className="h-4 w-4 text-blue-600" />
                        ) : (
                          <div className="h-3 w-3 rounded-full bg-gray-300"></div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Processing</h3>
                        <p className="apple-text-caption">
                          {order.status === "processing" || order.status === "delivered"
                            ? "Your order is being prepared"
                            : "Waiting to be processed"}
                        </p>
                      </div>
                    </div>

                    <div className="relative flex items-start gap-6">
                      <div
                        className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          order.status === "delivered" ? "bg-green-100" : "bg-gray-100"
                        }`}
                      >
                        {order.status === "delivered" ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <div className="h-3 w-3 rounded-full bg-gray-300"></div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Delivered</h3>
                        <p className="apple-text-caption">
                          {order.status === "delivered" ? "Your order has been delivered" : "Waiting to be delivered"}
                        </p>
                      </div>
                    </div>
                  </>
                )}

                {order.status === "cancelled" && (
                  <div className="relative flex items-start gap-6">
                    <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                      <XCircle className="h-4 w-4 text-red-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Order Cancelled</h3>
                      <p className="apple-text-caption">Your order has been cancelled</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Delivery Information */}
            <div className="apple-card p-6">
              <div className="flex items-center gap-3 mb-6">
                <Truck className="h-5 w-5 text-gray-700" />
                <h3 className="font-semibold text-gray-900">Delivery</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-1">Method</h4>
                  <p className="apple-text-body">{order.shipping_method || "Standard Delivery"}</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Address</h4>
                  {order.shipping_address ? (
                    <div className="apple-text-body space-y-1">
                      <p className="font-medium">
                        {order.shipping_address.first_name} {order.shipping_address.last_name}
                      </p>
                      <p>{order.shipping_address.address_line1}</p>
                      {order.shipping_address.address_line2 && <p>{order.shipping_address.address_line2}</p>}
                      <p>
                        {order.shipping_address.city}, {order.shipping_address.state}{" "}
                        {order.shipping_address.postal_code}
                      </p>
                      <p>{order.shipping_address.country}</p>
                      {order.shipping_address.phone && <p>Phone: {order.shipping_address.phone}</p>}
                    </div>
                  ) : (
                    <p className="apple-text-caption">No shipping address available</p>
                  )}
                </div>
              </div>
            </div>

            {/* Payment Information */}
            <div className="apple-card p-6">
              <div className="flex items-center gap-3 mb-6">
                <CreditCard className="h-5 w-5 text-gray-700" />
                <h3 className="font-semibold text-gray-900">Payment</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Method</h4>
                  <div className="flex items-center gap-2">
                    {order.payment_method?.toLowerCase().includes("mpesa") ? (
                      <>
                        <div className="h-6 w-6 rounded-full bg-green-500 flex items-center justify-center">
                          <CreditCard className="h-3 w-3 text-white" />
                        </div>
                        <span className="font-medium text-green-600">M-Pesa</span>
                      </>
                    ) : order.payment_method?.toLowerCase().includes("cash") ? (
                      <>
                        <div className="h-6 w-6 rounded-full bg-blue-500 flex items-center justify-center">
                          <CreditCard className="h-3 w-3 text-white" />
                        </div>
                        <span className="font-medium text-blue-600">Cash on Delivery</span>
                      </>
                    ) : (
                      <span className="apple-text-body">{order.payment_method || "Cash on Delivery"}</span>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Items total</span>
                      <span className="font-medium">{formatCurrency(order.subtotal || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Delivery</span>
                      <span className="font-medium">
                        {(order.shipping_cost || order.shipping || 0) === 0 ? (
                          <span className="text-green-600">Free</span>
                        ) : (
                          formatCurrency(order.shipping_cost || order.shipping || 0)
                        )}
                      </span>
                    </div>
                    {(order.tax || 0) > 0 && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Tax</span>
                        <span className="font-medium">{formatCurrency(order.tax || 0)}</span>
                      </div>
                    )}
                    <Separator className="my-3" />
                    <div className="flex justify-between text-base">
                      <span className="font-semibold text-gray-900">Total</span>
                      <span className="font-bold text-gray-900">
                        {formatCurrency(order.total_amount || order.total || 0)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Support */}
            <div className="apple-card p-6">
              <div className="flex items-center gap-3 mb-6">
                <MessageSquare className="h-5 w-5 text-gray-700" />
                <h3 className="font-semibold text-gray-900">Need Help?</h3>
              </div>

              <div className="space-y-3">
                <Button variant="outline" className="w-full apple-button-secondary justify-start bg-transparent">
                  <Phone className="h-4 w-4 mr-3" />
                  Contact Support
                </Button>
                <Button variant="outline" className="w-full apple-button-secondary justify-start bg-transparent">
                  <RefreshCw className="h-4 w-4 mr-3" />
                  Return Item
                </Button>
                <Button variant="outline" className="w-full apple-button-secondary justify-start bg-transparent">
                  <FileText className="h-4 w-4 mr-3" />
                  Report Issue
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="apple-card p-8 text-center">
          <div className="flex flex-wrap justify-center gap-8 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" />
              <span>Secure Shopping</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              <span>Fast Delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4" />
              <span>Quality Guarantee</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function OrderPage({ params }: { params: Promise<{ id: string; orderId: string }> }) {
  const resolvedParams = use(params)
  const orderId = resolvedParams.id || resolvedParams.orderId

  console.log("[v0] OrderPage: Resolved params:", resolvedParams)
  console.log("[v0] OrderPage: Extracted orderId:", orderId)

  return (
    <Suspense fallback={<OrderDetailsSkeleton />}>
      <OrderPageContent orderId={orderId} />
    </Suspense>
  )
}
